/** Automatically generated file. DO NOT MODIFY */
package com.emulator.detect;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}