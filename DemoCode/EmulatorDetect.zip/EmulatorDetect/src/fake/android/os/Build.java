package fake.android.os;

public class Build {
	public static final String BRAND = "google";
}
