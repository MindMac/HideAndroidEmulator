package com.emulator.detect;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.List;


import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Binder;
import android.os.Build;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import android.util.Log;

public class DetectUtils {
	
	static{
		System.loadLibrary("native");
	}
	
	public static boolean detectPhoneNumber(Context context){
		boolean isEmulator = false;
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		if(telephonyManager != null){
			String phoneNumber = telephonyManager.getLine1Number();
//			String networkOp = telephonyManager.getNetworkOperator();
//			String simNum = telephonyManager.getSimSerialNumber();
//			System.out.println("Test: " + phoneNumber + "-" + networkOp + "-" + simNum);
			int base = 5554;
			for(int i=0; i< 16; i++){
				int suffix = base + i * 2;
				if(phoneNumber.startsWith("1555521") && phoneNumber.endsWith(String.valueOf(suffix))){
					isEmulator = true;
					break;
				}
			}
			
		}
		return isEmulator;
	}
	
	public static boolean detectDeviceId(Context context){
		boolean isEmulator = false;
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		if(telephonyManager != null){
			String deviceId = telephonyManager.getDeviceId();
			if(deviceId.equals("000000000000000"))
				isEmulator = true;
			else
				isEmulator = false;
		}
		return isEmulator;
	}
	
	public static boolean detectBattery(Context context){
		IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		Intent batteryStatus = context.registerReceiver(null, intentFilter);
		int batteryLevel = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
		if(batteryLevel == 50)
			return true;
		else
			return false;
	}
	
	public static boolean detectWifiMac(Context context){
		WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
		WifiInfo wifiInfo = wifiManager.getConnectionInfo();
		String macAddr = wifiInfo.getMacAddress();
		if(macAddr == null)
			return true;
		else
			return false;
	}
	
	public static boolean detectBuildField(){
		String brand = Build.BRAND;
		if(brand.equals("generic"))
			return true;
		else
			return false;
	}
	
	public static boolean detectReflection(){
		boolean isEmulator = false;
		try {
			Class<?> systemPropertiesClass = Class.forName("android.os.SystemProperties");
			Method getMethod = systemPropertiesClass.getMethod("get", String.class);
			String property = (String) getMethod.invoke(systemPropertiesClass, 
					new Object[]{"ro.product.name"});
			if(property.equals("sdk"))
				isEmulator = true;
			else
				isEmulator = false;
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return isEmulator;
	}
	
	public static boolean detectBuildPropFile(){
		boolean isEmulator = false;
		String filePath = "/system/build.prop";
		File file = new File(filePath);
		if(file.exists()){
			String fileContent = readFile(file);
			if(fileContent.contains("ro.product.name=sdk"))
				isEmulator = true;
			else
				isEmulator = false;
		}
		return isEmulator;
	}
	
	public static boolean detectMonkey(){
		boolean isMonkey = ActivityManager.isUserAMonkey();
		if(isMonkey)
			return true;
		else
			return false;
	}
	
	public static boolean detectDrivers(){
		File file = new File("/proc/tty/drivers");
		String content = readFile(file);
		if(content.contains("goldfish"))
			return true;
		else
			return false;
	}
	
	
	public static boolean detectSpecialFile(){
		File qemu_file = new File("/dev/qemu_pipe");
		if(qemu_file.exists())
			return true;
		else
			return false;
	}
	
	public static boolean detectRuntime(){
		boolean isEmulator = false;
		Runtime runtime = Runtime.getRuntime();
		DataInputStream dataInputStream = null;
		try{
			Process process = runtime.exec("getprop");
			dataInputStream = new DataInputStream(process.getInputStream());  
	
			process.waitFor();
	
	    	byte[] buffer = new byte[dataInputStream.available()];  
	    	dataInputStream.read(buffer);  
	    	String res = new String(buffer);
	    	if(res.contains("[ro.product.device]: [generic]"))
	    		isEmulator = true;
	    	else
	    		isEmulator = false;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		if(dataInputStream != null){
			try {
				dataInputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}  
		
		return isEmulator;
	}
	

	@SuppressLint("SdCardPath")
	public static boolean detectGetPropWithNative(){
		boolean isEmulator = false;
		detectGetprop();
		
		try {
			Thread.sleep(10*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		File file = new File("/data/data/com.emulator.detect/getprop_out.txt");
		if(file.exists()){
			String content = readFile(file);
			if(content.contains("[ro.product.name]: [sdk]"))
				isEmulator = true;
			else
				isEmulator = false;
		}else
			isEmulator = false;
		return isEmulator;
	}
	
	public static boolean detectGetpropDirectlyWithNative(){
		if(detectGetpropDirectly())
			return true;
		else
			return false;
	}
	
	
	private static String readFile(File file){
		String fileContent = "";
		
		FileInputStream fileInputStream = null;
		InputStreamReader inputStreamReader = null;
		BufferedReader bufferReader = null;
		
		try {
			fileInputStream = new FileInputStream(file.getAbsolutePath());
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
			return fileContent;
		}
		
		inputStreamReader = new InputStreamReader(fileInputStream);
		bufferReader = new BufferedReader(inputStreamReader);
		
		try {
			String dataString = null;
			while ((dataString = bufferReader.readLine()) != null) {
				if (dataString.isEmpty())
					continue;
				fileContent += dataString;
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if(bufferReader != null){
				try{
					bufferReader.close();
				}catch(IOException ex){
					ex.printStackTrace();
				}
			}
			
			if(inputStreamReader != null){
				try {
					inputStreamReader.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
			
			if(bufferReader != null){
				try {
					bufferReader.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
		return fileContent;
	}
	
	public static boolean detectTaintDroid(){
		boolean isEmulator = false;
		try{
			Class.forName("dalvik.system.Taint");
			isEmulator = true;
		}catch(Exception ex){
			isEmulator = false;
		}
		return isEmulator;
	}
	
	
	public static boolean detectCPUInfo(){
		File file = new File("/proc/cpuinfo");
		String content = readFile(file);
		if(content.contains("Goldfish"))
			return true;
		else
			return false;
	}
	
	public static boolean detectBluetooth(){
		BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();
		if(bluetooth == null)
			return true;
		else
			return false;
		
	}
	
	public static boolean detectSpecialPackage(Context context){
		// Query directly
		boolean isEmulator = false;
		PackageManager pkgManager = context.getPackageManager();
		try {
			PackageInfo pkgInfo = pkgManager.getPackageInfo("com.example.android.apis", PackageManager.GET_META_DATA);
			isEmulator = true;
		} catch (NameNotFoundException e) {
			isEmulator = false;
		}
		
		List<PackageInfo> pkgInfos = pkgManager.getInstalledPackages(PackageManager.GET_META_DATA);
		boolean pkgFound = false;
		for(PackageInfo pkgInfo : pkgInfos){
			if(pkgInfo.packageName.equals("com.example.android.apis")){
				pkgFound = true;
				break;
			}	
		}
		if(pkgFound)
			isEmulator = true;
		else
			isEmulator = false;
		
		return isEmulator;
	}
	
	
	public static boolean detectContacts(Context context){
		Cursor cur = context.getContentResolver().
				query(ContactsContract.Contacts.CONTENT_URI, 
						null, null, null, null);
		int num = cur.getCount();
		if(num == 0)
			return true;
		else
			return false;
	}
	
	public static boolean detectFileWithNative(){
		if(detectFileExists())
			return true;
		else
			return false;
	}
	
	public native static int detectGetprop();
	public native static boolean detectGetpropDirectly();
	public native static boolean detectFileExists();
	public native static String getPathFromFd(int pid, int fd);
	
	
	public static void testPath(){
		System.out.println(getPathFromFd(Binder.getCallingPid(), 15));
	}
	
	
	
}
