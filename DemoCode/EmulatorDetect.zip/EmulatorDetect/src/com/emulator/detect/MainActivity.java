package com.emulator.detect;

import com.emulator.detect.R;

import android.app.Activity;
import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class MainActivity extends Activity {

	private static final String LOG_TAG = "EmulatorDetect";
	private static final String mIsEmulator = "The device is an Android emulator";
	private static final String mIsNoEmulator = "The device is not an Android emulator";
	
	private static Button monkeyBtn = null;
	private static Button batteryBtn = null;
	private static Button nativeBtn = null;
	
	public void emulatorDetect(Context context){
		
		if(DetectUtils.detectPhoneNumber(context)){
			Log.i(LOG_TAG, String.format("TelephonyManager-PhoneNumber: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("TelephonyManager-PhoneNumber: %s", mIsNoEmulator));
		}
		
		if(DetectUtils.detectWifiMac(context)){
			Log.i(LOG_TAG, String.format("Wifi-MacAddress: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("Wifi-MacAddress: %s", mIsNoEmulator));
		}
		
		if(DetectUtils.detectBuildField()){
			Log.i(LOG_TAG, String.format("Build Field: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("Build Field: %s", mIsNoEmulator));
		}
		
		if(DetectUtils.detectReflection()){
			Log.i(LOG_TAG, String.format("Java Reflection: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("Java Reflection: %s", mIsNoEmulator));
		}
		
		if(DetectUtils.detectBuildPropFile()){
			Log.i(LOG_TAG, String.format("/system/build.prop: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("/system/build.prop: %s", mIsNoEmulator));
		}
		
		if(DetectUtils.detectDrivers()){
			Log.i(LOG_TAG, String.format("System Drivers: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("System Drivers: %s", mIsNoEmulator));
		}
		
		if(DetectUtils.detectSpecialFile()){
			Log.i(LOG_TAG, String.format("/dev/qemu_pipe: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("/dev/qemu_pipe: %s", mIsNoEmulator));
		}
		
		if(DetectUtils.detectRuntime()){
			Log.i(LOG_TAG, String.format("Runtime Shell: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("Runtime Shell: %s", mIsNoEmulator));
		}
		
		if(DetectUtils.detectGetPropWithNative()){
			Log.i(LOG_TAG, String.format("Native Code-getprop: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("Native Code-getprop: %s", mIsNoEmulator));
		}
		
		if(DetectUtils.detectGetpropDirectlyWithNative()){
			Log.i(LOG_TAG, String.format("Native Code-__system_property_get: %s", mIsEmulator));
		}else{
			Log.i(LOG_TAG, String.format("Native Code-__system_property_get: %s", mIsNoEmulator));
		}
		
		
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		if (savedInstanceState == null) {
			getFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
		
		emulatorDetect(MainActivity.this);
		
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			monkeyBtn = (Button) rootView.findViewById(R.id.monkeyBtn);
			batteryBtn = (Button) rootView.findViewById(R.id.batteryBtn);
			nativeBtn = (Button) rootView.findViewById(R.id.nativeBtn);
			
			monkeyBtn.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if(DetectUtils.detectMonkey()){
						Log.i(LOG_TAG, String.format("Monkey: %s", mIsEmulator));
					}else{
						Log.i(LOG_TAG, String.format("Monkey: %s", mIsNoEmulator));
					}
				}
			});
			
			batteryBtn.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if(DetectUtils.detectBattery(v.getContext())){
						Log.i(LOG_TAG, String.format("Battery Status: %s", mIsEmulator));
					}else{
						Log.i(LOG_TAG, String.format("Battery Status: %s", mIsNoEmulator));
					}
				}
			});
			
			nativeBtn.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if(DetectUtils.detectGetpropDirectlyWithNative()){
						Log.i(LOG_TAG, String.format("Native Code-__system_property_get: %s", mIsEmulator));
					}else{
						Log.i(LOG_TAG, String.format("Native Code-__system_property_get: %s", mIsNoEmulator));
					}
				}
			});
			
			return rootView;
		}
	}

}
