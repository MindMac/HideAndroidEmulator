#include <jni.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/system_properties.h>

JNIEXPORT jint JNICALL Java_com_emulator_detect_DetectUtils_detectGetprop( JNIEnv* env, jobject thiz )
{
	if(fork() == 0){
		int fd = open("/data/data/com.emulator.detect/getprop_out.txt", O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
		dup2(fd, 1);
		dup2(fd, 2);
		close(fd);

		int retval = execlp("getprop", "getprop", NULL);
	}
	return 0;
}

JNIEXPORT jboolean JNICALL Java_com_emulator_detect_DetectUtils_detectGetpropDirectly( JNIEnv* env, jobject thiz )
{
	int len;
	char buf[1024];
	len = __system_property_get("ro.product.name", buf);
	return (strcmp(buf, "sdk") == 0);
}

JNIEXPORT jboolean JNICALL Java_com_emulator_detect_DetectUtils_detectFileExists( JNIEnv* env, jobject thiz )
{
	struct stat  buffer;
	return (stat ("/dev/qemu_pipe", &buffer) == 0);
}

JNIEXPORT jstring JNICALL Java_com_emulator_detect_DetectUtils_getPathFromFd( JNIEnv* env, jobject thiz, jint pid, jint fd){
	char ppath[20];
	char rpath[20];
	char buffer[(2*120)+1] = "";
	char *pbuffer = buffer;
	int len, i;
	//pid = 1409;
	snprintf(ppath, 20, "/proc/%d/fd/%d", pid, fd);
	int err = readlink(ppath, rpath, sizeof(rpath));

	if(err >= 0){
		int pos = (err < sizeof(rpath)) ? err: sizeof(rpath)-1;
		rpath[pos] = '\0';
		len = strlen(rpath);
		for (i = 0; i < len; i++) {
			sprintf(pbuffer, "%x", rpath[i]);
			pbuffer += 2;
		}
		//return (*env)->NewStringUTF(env, "Right finding path!");
		return (*env)->NewStringUTF(env, buffer);
	}else{
		return (*env)->NewStringUTF(env, "Error finding path!");
	}


}
